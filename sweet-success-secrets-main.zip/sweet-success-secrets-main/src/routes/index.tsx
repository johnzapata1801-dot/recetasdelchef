import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CTAButton } from "@/components/CTAButton";
import {
  AlarmClock,
  Check,
  CreditCard,
  Flame,
  MessageCircle,
  ShieldCheck,
  Star,
  X,
  Zap,
} from "lucide-react";

import heroCookie from "@/assets/hero-cookie-hand.jpg";
import cookie1 from "@/assets/cookies-stack.jpg";
import cookie2 from "@/assets/coffee-cookies.jpg";
import cookie3 from "@/assets/packaging.jpg";
import cookie4 from "@/assets/whatsapp-orders.jpg";
import wa1 from "@/assets/whatsapp-1.jpg";
import wa2 from "@/assets/whatsapp-2.jpg";
import wa3 from "@/assets/whatsapp-3.jpg";

export const Route = createFileRoute("/")({
  component: LandingPage,
  head: () => ({
    meta: [
      { title: "Cookies Caseras — Guía práctica para principiantes" },
      {
        name: "description",
        content:
          "Aprende a preparar y presentar cookies caseras con una guía simple, paso a paso, pensada para quienes quieren empezar desde casa.",
      },
    ],
  }),
});

function useCountdown(initial = 59 * 60) {
  const [seconds, setSeconds] = useState(initial);
  useEffect(() => {
    const t = setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);
  const m = String(Math.floor(seconds / 60)).padStart(2, "0");
  const s = String(seconds % 60).padStart(2, "0");
  return `${m}:${s}`;
}

const features = [
  { title: "Receta base universal", desc: "Una base fácil para muchas variaciones" },
  { title: "Textura ideal", desc: "Aprende la consistencia perfecta" },
  { title: "Presentación bonita", desc: "Cookies que enamoran a la vista" },
  { title: "Guía de precios", desc: "Calcula tus costos con claridad" },
  { title: "Conservación", desc: "Tips para mantener su frescura" },
  { title: "Variedad de sabores", desc: "Ideas para ampliar tu menú" },
];

const tradicionais = [
  "Cookie clásico americano – base perfecta crocante",
  "Cookie de chocolate blanco – dulce y suave",
  "Cookie de nueces – con textura crocante",
  "Cookie de avena – sabor casero",
  "Cookie red velvet – elegante y clásico",
  "Cookie de café – aromático e intenso",
];
const gourmet = [
  "Cookie selva negra – cerezas y crema",
  "Cookie 3 capas – muy visual",
  "Cookie de dulce de leche – cremoso",
  "Cookie sensación – fresa y chocolate",
  "Cookie estilo Oreo – crocante y suave",
  "Cookie diamante negro – sofisticado",
];
const especiais = [
  "Cookie sin azúcar – opción ligera",
  "Cookie sin lactosa – inclusivo",
  "Cookie low carb – versión fitness",
  "Cookie vegano – 100% vegetal",
  "Cookie en taza – rápido y práctico",
  "Cookie de banana – naturalmente dulce",
];

const passos = [
  { t: "Prepara la masa correcta", d: "Técnica simple para una textura ideal" },
  { t: "Variaciones y rellenos", d: "Ideas con chocolate, frutos secos y más" },
  { t: "Modelado y horneado", d: "Acabado prolijo paso a paso" },
  { t: "Empaque que enamora", d: "Presentación cuidada para tus pedidos" },
  { t: "Ofrece tus cookies", d: "Ideas prácticas para empezar desde casa" },
];

const bonus = [
  { n: 1, t: "Planilla de costos y pedidos", d: "Organiza tus insumos, pedidos y entregas con claridad.", v: "Incluido" },
  { n: 2, t: "Guía básica de precios", d: "Aprende a calcular el precio sugerido de tus cookies.", v: "Incluido" },
  { n: 3, t: "Mini guía de empaque", d: "Ideas simples para presentar tus productos de forma bonita.", v: "Incluido" },
  { n: 4, t: "Libro de combinaciones", d: "Variaciones creativas a partir de la receta base.", v: "Incluido" },
  { n: 5, t: "Ideas para ofrecer más", d: "Sugerencias prácticas de promoción desde casa.", v: "Incluido" },
  { n: 6, t: "Método 5P Cookies", d: "Un sistema simple en 5 pasos: Preparar, Personalizar, Presentar, Promocionar y Perseverar.", v: "Incluido" },
  { n: 7, t: "Guía básica de ventas", d: "Pensada para quienes recién empiezan a ofrecer sus productos.", v: "Incluido" },
  { n: 8, t: "Acceso digital inmediato", d: "Recibe todo el contenido apenas confirmes tu compra.", v: "Incluido" },
];

const faqs = [
  { q: "¿Necesito experiencia previa?", a: "No. El contenido está pensado para principiantes, con explicaciones claras y paso a paso." },
  { q: "¿Cómo recibo el contenido?", a: "Recibes el acceso digital de forma inmediata después de confirmar tu compra." },
  { q: "¿Está en español?", a: "Sí, todo el material está en español, con un lenguaje simple y directo." },
  { q: "¿Puedo verlo desde el celular?", a: "Sí. Está optimizado para celular, tablet o computadora." },
  { q: "¿Existe garantía?", a: "Sí, cuentas con 14 días de garantía de satisfacción. Si no es para ti, te devolvemos tu dinero." },
];

function LandingPage() {
  const time = useCountdown();
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top urgency bar */}
      <div className="sticky top-0 z-50 bg-destructive text-destructive-foreground">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-x-3 gap-y-1 px-4 py-2 text-center text-[11px] font-bold uppercase tracking-wide sm:text-xs">
          <span className="flex items-center gap-1.5">⏰ Precio promocional por tiempo limitado</span>
          <span className="flex items-center gap-1.5 rounded-full bg-black/30 px-2.5 py-1">
            <AlarmClock className="h-3 w-3" /> {time}
          </span>
          <span className="flex items-center gap-1.5 rounded-full bg-black/30 px-2.5 py-1">
            <span className="h-1.5 w-1.5 rounded-full bg-yellow-300" /> Cupos limitados
          </span>
        </div>
      </div>

      {/* HERO */}
      <section className="relative overflow-hidden px-5 pb-12 pt-10 sm:pt-16">
        <div className="absolute -top-32 left-1/2 h-[480px] w-[480px] -translate-x-1/2 rounded-full bg-orange/20 blur-[120px]" />
        <div className="relative mx-auto max-w-3xl text-center animate-fade-up">
          <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-border/60 bg-card/60 px-3 py-1.5 backdrop-blur">
            <div className="flex -space-x-1.5">
              <span className="h-5 w-5 rounded-full bg-gradient-orange ring-2 ring-background text-[9px] font-bold flex items-center justify-center">M</span>
              <span className="h-5 w-5 rounded-full bg-pink-500 ring-2 ring-background text-[9px] font-bold flex items-center justify-center">J</span>
              <span className="h-5 w-5 rounded-full bg-amber-400 ring-2 ring-background text-[9px] font-bold flex items-center justify-center text-black">A</span>
            </div>
            <span className="text-xs">
              <span className="text-orange font-bold">★★★★★ 4.9</span>
              <span className="ml-1 text-muted-foreground">Comunidad activa de aprendices</span>
            </span>
          </div>

          <h1 className="text-balance font-display text-4xl font-black leading-[1.05] sm:text-6xl">
            Aprende a preparar y presentar{" "}
            <span className="text-gradient-orange">cookies caseras</span> con una guía práctica{" "}
            <span className="text-gradient-orange">pensada para principiantes</span>
          </h1>

          <div className="relative mx-auto mt-8 w-full max-w-md">
            <div className="absolute inset-0 -z-10 rounded-3xl bg-orange/30 blur-3xl" />
            <img
              src={heroCookie}
              alt="Cookie casera recién horneada"
              width={1024}
              height={1024}
              className="aspect-square w-full rounded-3xl object-cover shadow-glow"
            />
            <p className="mt-3 text-xs text-muted-foreground">Recetas claras y paso a paso</p>
            <p className="text-sm font-semibold text-orange">Contenido pensado para empezar desde casa 🍪</p>
          </div>

          <p className="mx-auto mt-8 max-w-xl text-base text-muted-foreground sm:text-lg">
            Descubre <strong className="text-foreground">recetas irresistibles</strong>, ideas simples para{" "}
            <strong className="text-foreground">ofrecer tus productos</strong> y herramientas para organizarte mejor.
          </p>

          <div className="mt-8 flex flex-col items-center gap-2">
            <div className="flex items-center gap-3">
              <span className="text-muted-foreground line-through">USD 29</span>
              <span className="rounded-full bg-orange/20 px-2.5 py-1 text-xs font-bold text-orange">Oferta de lanzamiento</span>
            </div>
            <div className="flex items-baseline gap-3">
              <span className="text-sm text-muted-foreground">por solo</span>
              <span className="font-display text-5xl font-black text-gradient-orange sm:text-6xl">USD 7,90</span>
            </div>
            <p className="mt-1 text-sm font-semibold text-success">✓ Acceso digital inmediato + Garantía de 14 días</p>
          </div>

          <div className="mx-auto mt-6 max-w-md">
            <a href="#oferta">
              <CTAButton>Quiero ver el contenido</CTAButton>
            </a>
            <p className="mt-3 flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <MessageCircle className="h-3.5 w-3.5" /> Acceso enviado por correo / WhatsApp
            </p>
            <p className="text-xs text-muted-foreground">Material liberado al confirmar tu compra</p>
            <div className="mt-3 flex items-center justify-center gap-4 text-xs font-semibold">
              <span className="text-orange">★★★★★ 4.9/5</span>
              <span className="flex items-center gap-1 text-muted-foreground"><AlarmClock className="h-3 w-3" /> Acceso inmediato</span>
            </div>
          </div>
        </div>
      </section>

      {/* GALLERY */}
      <section className="px-5 py-14">
        <div className="mx-auto max-w-5xl text-center">
          <h2 className="font-display text-3xl font-black text-gradient-orange sm:text-4xl">Cookies caseras irresistibles</h2>
          <p className="mt-3 text-muted-foreground">Recetas testeadas, fáciles de aplicar y con resultados visuales hermosos.</p>

          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[cookie1, cookie2, cookie3, cookie4].map((src, i) => (
              <img
                key={i}
                src={src}
                alt={`Cookie casera ${i + 1}`}
                loading="lazy"
                className="aspect-square w-full rounded-2xl object-cover shadow-card transition-transform duration-300 hover:-translate-y-1"
              />
            ))}
          </div>

          <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="rounded-2xl border border-border/60 bg-card p-4 text-left">
                <div className="font-display text-sm font-bold text-orange">{f.title}</div>
                <div className="mt-1 text-xs text-muted-foreground">{f.desc}</div>
              </div>
            ))}
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {[
              { title: "Cookies tradicionales", items: tradicionais },
              { title: "Cookies gourmet", items: gourmet },
              { title: "Cookies especiales", items: especiais },
            ].map((col) => (
              <div key={col.title} className="rounded-2xl border border-border/60 bg-card p-5 text-left">
                <h3 className="font-display text-base font-bold text-orange">{col.title}</h3>
                <ul className="mt-3 space-y-2 text-sm">
                  {col.items.map((it) => (
                    <li key={it} className="flex gap-2">
                      <Star className="mt-0.5 h-4 w-4 shrink-0 fill-orange text-orange" />
                      <span className="text-muted-foreground">{it}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mx-auto mt-10 max-w-3xl rounded-2xl bg-gradient-orange p-1 shadow-glow">
            <div className="rounded-[14px] px-5 py-4 text-center font-display text-base font-extrabold text-white sm:text-lg">
              ✨ Una habilidad práctica que puedes aplicar desde casa, paso a paso.
            </div>
          </div>
        </div>
      </section>

      {/* MÉTODO */}
      <section className="px-5 py-14">
        <div className="mx-auto max-w-3xl">
          <div className="text-center">
            <h2 className="font-display text-3xl font-black sm:text-4xl">
              Método <span className="text-gradient-orange">5P Cookies</span>
            </h2>
            <p className="mt-3 text-muted-foreground">Un sistema simple y claro para aprender desde cero</p>
          </div>

          <div className="mt-8 space-y-3">
            {passos.map((p, i) => (
              <div key={p.t} className="flex items-center gap-4 rounded-2xl border border-border/60 bg-card p-4 shadow-card">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-orange font-display text-base font-black text-white shadow-glow">
                  {i + 1}
                </div>
                <div>
                  <div className="font-display text-base font-bold">{p.t}</div>
                  <div className="text-sm text-muted-foreground">{p.d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BÔNUS */}
      <section className="px-5 py-14">
        <div className="mx-auto max-w-5xl">
          <div className="text-center">
            <h2 className="font-display text-3xl font-black sm:text-4xl">
              Todo lo que <span className="text-gradient-orange">incluye el pack</span>
            </h2>
            <p className="mt-3 text-muted-foreground">Contenido práctico, claro y fácil de aplicar</p>
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {bonus.map((b) => (
              <div
                key={b.n}
                className="relative flex gap-4 rounded-2xl border border-orange/30 bg-card p-5 shadow-card transition-transform hover:-translate-y-1"
              >
                <div className="absolute -top-3 left-4 rounded-full bg-gradient-orange px-3 py-1 text-[10px] font-black uppercase tracking-wider text-white shadow-glow">
                  Incluye #{b.n}
                </div>
                <div className="flex-1 pt-2">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-display text-base font-bold leading-tight">{b.t}</h3>
                    <span className="shrink-0 text-xs text-orange font-bold">{b.v}</span>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{b.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div className="overflow-hidden border-y border-orange/40 bg-gradient-orange py-3">
        <div className="flex w-max animate-marquee gap-8 whitespace-nowrap font-display text-sm font-black uppercase tracking-wider text-white sm:text-base">
          {Array.from({ length: 2 }).map((_, k) => (
            <div key={k} className="flex gap-8">
              {["🎁 Bonos incluidos", "💎 Pack completo", "✨ Acceso digital inmediato", "🍪 Recetas paso a paso"].flatMap((x) => [
                <span key={x + k}>{x}</span>,
                <span key={x + "dot" + k} className="opacity-60">•</span>,
              ])}
            </div>
          ))}
        </div>
      </div>

      {/* TESTIMONIALS */}
      <section className="px-5 py-14">
        <div className="mx-auto max-w-5xl text-center">
          <p className="text-xs font-bold uppercase tracking-widest text-orange">💬 Lo que dicen nuestras alumnas</p>
          <h2 className="mt-3 font-display text-3xl font-black sm:text-4xl">
            Comentarios <span className="text-gradient-orange">de la comunidad</span>
          </h2>
          <p className="mt-3 text-muted-foreground">Opiniones reales sobre el contenido del pack</p>

          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {[
              { src: wa1, text: "“Las recetas son muy fáciles de seguir.”" },
              { src: wa2, text: "“Todo está explicado de forma muy clara.”" },
              { src: wa3, text: "“Me ayudó a organizar mejor mis pedidos.”" },
            ].map((t, i) => (
              <div key={i} className="overflow-hidden rounded-2xl border border-border/60 bg-card shadow-card">
                <img
                  src={t.src}
                  alt={`Comentario ${i + 1}`}
                  loading="lazy"
                  className="w-full"
                />
                <p className="px-4 py-3 text-sm text-muted-foreground">{t.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OFFER */}
      <section id="oferta" className="px-5 py-14">
        <div className="mx-auto max-w-5xl">
          <div className="text-center">
            <p className="text-xs font-bold uppercase tracking-widest text-orange">✨ Oferta de lanzamiento</p>
            <h2 className="mt-3 font-display text-3xl font-black uppercase sm:text-4xl">
              Elige el plan ideal <span className="text-gradient-orange">para empezar</span>
            </h2>
            <p className="mt-3 text-muted-foreground">Acceso digital inmediato apenas confirmes tu compra</p>
          </div>

          <div className="mt-10 grid gap-6 lg:grid-cols-2">
            {/* Combo */}
            <div className="relative rounded-3xl border-2 border-orange bg-card p-6 shadow-glow">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-orange px-4 py-1 text-[10px] font-black uppercase tracking-widest text-white shadow-glow">
                Más elegido
              </div>
              <h3 className="font-display text-xl font-extrabold">Pack completo + bonos</h3>
              <p className="mt-1 text-sm text-muted-foreground">Recetario + método 5P + todas las guías y planillas</p>
              <div className="mt-5 flex items-baseline gap-3">
                <span className="text-base text-muted-foreground line-through">USD 49</span>
                <span className="font-display text-4xl font-black text-gradient-orange">USD 12,90</span>
              </div>
              <p className="text-xs text-muted-foreground">Pago único · Acceso digital</p>

              <ul className="mt-5 space-y-2.5 text-sm">
                {[
                  "Recetario de cookies tradicionales, gourmet y especiales",
                  "Método 5P Cookies paso a paso",
                  "Guía básica de ventas desde casa",
                  "Libro de combinaciones y variaciones",
                  "Guía básica de precios",
                  "Planilla de costos y control de pedidos",
                  "Mini guía de presentación y empaque",
                ].map((it) => (
                  <li key={it} className="flex gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                    <span>{it}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-5 rounded-2xl border border-orange/40 bg-orange/5 p-4 text-left">
                <div className="font-display text-xs font-extrabold uppercase tracking-wider text-orange">+ Extras incluidos</div>
                <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
                  <li>· Ideas prácticas para ofrecer tus productos</li>
                  <li>· Tips de presentación estilo Pinterest</li>
                  <li>· Plantilla editable de pedidos</li>
                  <li>· Acceso digital inmediato</li>
                  <li>· Garantía de satisfacción de 14 días</li>
                </ul>
              </div>

              <div className="mt-6">
                <CTAButton>Quiero el pack completo</CTAButton>
              </div>
            </div>

            {/* Básico */}
            <div className="rounded-3xl border border-border/60 bg-card/60 p-6">
              <h3 className="font-display text-xl font-extrabold text-muted-foreground">Solo recetario</h3>
              <p className="mt-1 text-sm text-muted-foreground">Opción básica para empezar</p>
              <div className="mt-5 flex items-baseline gap-3">
                <span className="text-base text-muted-foreground line-through">USD 19</span>
                <span className="font-display text-4xl font-black">USD 7,90</span>
              </div>
              <p className="text-xs text-muted-foreground">Pago único · Acceso digital</p>

              <ul className="mt-5 space-y-2.5 text-sm">
                {["Recetario base en PDF", "Acceso digital inmediato"].map((it) => (
                  <li key={it} className="flex gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                    <span>{it}</span>
                  </li>
                ))}
                {["Método 5P", "Guía de ventas", "Planilla de pedidos", "Guía de empaque"].map((it) => (
                  <li key={it} className="flex gap-2 text-muted-foreground/60">
                    <X className="mt-0.5 h-4 w-4 shrink-0" />
                    <span className="line-through">{it}</span>
                  </li>
                ))}
              </ul>

              <button className="mt-6 w-full rounded-2xl border border-border bg-secondary py-4 font-display text-sm font-bold text-foreground transition hover:bg-secondary/70">
                Quiero solo el recetario
              </button>
            </div>
          </div>

          <div className="mt-10 text-center">
            <p className="font-display text-sm font-bold">Pago 100% seguro</p>
            <div className="mt-3 flex flex-wrap items-center justify-center gap-x-8 gap-y-2 text-sm">
              <div><div className="font-bold">Tarjeta</div><div className="text-xs text-muted-foreground">Crédito / débito</div></div>
              <div><div className="font-bold">PayPal</div><div className="text-xs text-muted-foreground">Internacional</div></div>
              <div><div className="font-bold">Transferencia</div><div className="text-xs text-muted-foreground">Local</div></div>
            </div>
            <p className="mt-3 flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <MessageCircle className="h-3.5 w-3.5" /> Acceso enviado por correo / WhatsApp
            </p>
          </div>
        </div>
      </section>

      {/* GUARANTEE */}
      <section className="px-5 py-14">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-display text-3xl font-black sm:text-4xl">
            Garantía de satisfacción <span className="text-gradient-orange">de 14 días</span>
          </h2>
          <div className="mt-6 rounded-3xl border border-border/60 bg-card p-8 shadow-card">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/15">
              <ShieldCheck className="h-8 w-8 text-success" />
            </div>
            <p className="mt-5 text-base text-muted-foreground">
              Si por cualquier motivo el contenido no es para ti, te devolvemos{" "}
              <mark className="rounded bg-orange/20 px-1 text-orange">el 100% de tu compra</mark>. Sin preguntas, sin trámites complicados.
            </p>
            <p className="mt-3 text-sm text-muted-foreground">Tienes 14 días para revisar todo el material con calma.</p>
          </div>
          <p className="mt-6 text-xs font-bold uppercase tracking-widest text-orange">Cupos limitados con precio promocional</p>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="px-5 py-14">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl font-black sm:text-4xl">
            Empieza hoy desde <span className="text-gradient-orange">tu propia cocina</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            Una guía simple y práctica para aprender a preparar y presentar cookies caseras paso a paso.
          </p>
          <div className="mx-auto mt-6 max-w-md">
            <a href="#oferta">
              <CTAButton>Quiero ver el contenido</CTAButton>
            </a>
          </div>
          <div className="mt-4 flex items-center justify-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><MessageCircle className="h-3.5 w-3.5" /> Acceso digital inmediato</span>
            <span className="flex items-center gap-1"><ShieldCheck className="h-3.5 w-3.5" /> Garantía de 14 días</span>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="px-5 py-14">
        <div className="mx-auto max-w-2xl">
          <h2 className="text-center font-display text-3xl font-black sm:text-4xl">
            Preguntas <span className="text-gradient-orange">frecuentes</span>
          </h2>
          <Accordion type="single" collapsible className="mt-8 space-y-3">
            {faqs.map((f, i) => (
              <AccordionItem
                key={i}
                value={`q${i}`}
                className="rounded-2xl border border-border/60 bg-card px-5"
              >
                <AccordionTrigger className="font-display text-sm font-bold text-foreground hover:no-underline">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-border/60 px-5 py-10">
        <div className="mx-auto max-w-5xl text-center text-xs text-muted-foreground">
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 font-semibold">
            <span className="flex items-center gap-1"><CreditCard className="h-3.5 w-3.5" /> Tarjeta · PayPal · Transferencia</span>
            <span className="flex items-center gap-1"><ShieldCheck className="h-3.5 w-3.5" /> Garantía 14 días</span>
            <span className="flex items-center gap-1"><Zap className="h-3.5 w-3.5" /> Acceso inmediato</span>
          </div>
          <p className="mt-4">© {new Date().getFullYear()} Cookies Caseras — Todos los derechos reservados.</p>
          <p className="mt-1">Contacto · Política de privacidad · Términos de uso</p>
        </div>
      </footer>
    </div>
  );
}
