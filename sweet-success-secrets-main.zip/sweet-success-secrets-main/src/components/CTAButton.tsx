import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ComponentProps } from "react";

export function CTAButton({ className, children, ...props }: ComponentProps<typeof Button>) {
  return (
    <Button
      className={cn(
        "h-auto w-full rounded-2xl bg-gradient-orange px-8 py-5 text-base font-extrabold uppercase tracking-wide text-white shadow-button transition-all duration-300 hover:-translate-y-0.5 hover:brightness-110 sm:py-6 sm:text-lg animate-pulse-glow",
        className
      )}
      {...props}
    >
      {children}
    </Button>
  );
}
